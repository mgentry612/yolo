
live_olives - v1 2020-11-03 8:46am
==============================

This dataset was exported via roboflow.ai on November 3, 2020 at 1:47 PM GMT

It includes 377 images.
Olive are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* 50% probability of horizontal flip
* 50% probability of vertical flip
* Random rotation of between -15 and +15 degrees


