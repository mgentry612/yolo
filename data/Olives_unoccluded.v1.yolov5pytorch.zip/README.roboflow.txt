
Olives_unoccluded - v1 2020-09-12 2:08pm
==============================

This dataset was exported via roboflow.ai on September 12, 2020 at 6:08 PM GMT

It includes 243 images.
Olive are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* 50% probability of horizontal flip
* 50% probability of vertical flip
* Equal probability of one of the following 90-degree rotations: none, clockwise, counter-clockwise, upside-down


