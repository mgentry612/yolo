
BCCD - v1 resize-416x416
==============================

This dataset was exported via roboflow.ai on June 10, 2020 at 6:43 AM GMT

It includes 364 images.
Cells are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


