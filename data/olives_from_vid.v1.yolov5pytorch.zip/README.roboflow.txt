
olives_from_vid - v1 2020-09-12 4:52pm
==============================

This dataset was exported via roboflow.ai on September 12, 2020 at 8:53 PM GMT

It includes 45 images.
Olive are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


